import Navigation from "./components/Navigation";

const App = () => {
  return (
    <div>
      <Navigation />
    </div>
  );
};
export default App;
