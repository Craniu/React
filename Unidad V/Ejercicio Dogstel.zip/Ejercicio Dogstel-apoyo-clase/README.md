# React + Vite

## Instalación

```
npm install
```

## Ejecución

```
npm run dev
```
